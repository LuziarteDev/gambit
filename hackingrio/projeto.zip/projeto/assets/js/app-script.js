
$(function() {
	"use strict";
	
	$('.prob-geral-bar.progress-bar.bg-success').css('width', $('.prob-geral-prog.mb-0.py-3.text-success').text( ));

	$(document).on('change', '.prob-geral-bar.progress-bar.bg-success', function(){
		$('.prob-geral-bar.progress-bar.bg-success').css('width', $('.prob-geral-prog.mb-0.py-3.text-success').text( ));

	});

	//sidebar menu js
$.sidebarMenu($('.sidebar-menu'));

// === toggle-menu js
$(".toggle-menu").on("click", function(e) {
        e.preventDefault();
        $("#wrapper").toggleClass("toggled");
    });	 
	   
// === sidebar menu activation js

$(function() {
        for (var i = window.location, o = $(".sidebar-menu a").filter(function() {
            return this.href == i;
        }).addClass("active").parent().addClass("active"); ;) {
            if (!o.is("li")) break;
            o = o.parent().addClass("in").parent().addClass("active");
        }
    }), 	   
	   



/* Back To Top */

$(document).ready(function(){ 
    $(window).on("scroll", function(){ 
        if ($(this).scrollTop() > 300) { 
            $('.back-to-top').fadeIn(); 
        } else { 
            $('.back-to-top').fadeOut(); 
        } 
    }); 

    $('.back-to-top').on("click", function(){ 
        $("html, body").animate({ scrollTop: 0 }, 600); 
        return false; 
    }); 
});	   
	   

  // page loader

    $(window).on('load', function(){

     $('#pageloader-overlay').fadeOut(1000);

    })  
   
   
$(function () {
  $('[data-toggle="popover"]').popover()
})


$(function () {
  $('[data-toggle="tooltip"]').tooltip()
})


	 // theme setting
	 $(".switcher-icon").on("click", function(e) {
        e.preventDefault();
        $(".right-sidebar").toggleClass("right-toggled");
    });
	
	$('#theme1').click(theme1);
    $('#theme2').click(theme2);
    $('#theme3').click(theme3);
    $('#theme4').click(theme4);
    $('#theme5').click(theme5);
    $('#theme6').click(theme6);
    $('#theme7').click(theme7);
    $('#theme8').click(theme8);
    $('#theme9').click(theme9);
    $('#theme10').click(theme10);
    $('#theme11').click(theme11);
    $('#theme12').click(theme12);

    function theme1() {
      $('#sidebar-wrapper').attr('class', 'bg-theme bg-theme1');
    }

    function theme2() {
      $('#sidebar-wrapper').attr('class', 'bg-theme bg-theme2');
    }

    function theme3() {
      $('#sidebar-wrapper').attr('class', 'bg-theme bg-theme3');
    }

    function theme4() {
      $('#sidebar-wrapper').attr('class', 'bg-theme bg-theme4');
    }
	
	function theme5() {
      $('#sidebar-wrapper').attr('class', 'bg-theme bg-theme5');
    }
	
	function theme6() {
      $('#sidebar-wrapper').attr('class', 'bg-theme bg-theme6');
    }

    function theme7() {
      $('#sidebar-wrapper').attr('class', 'bg-theme bg-theme7');
    }

    function theme8() {
      $('#sidebar-wrapper').attr('class', 'bg-theme bg-theme8');
    }

    function theme9() {
      $('#sidebar-wrapper').attr('class', 'bg-theme bg-theme9');
    }

    function theme10() {
      $('#sidebar-wrapper').attr('class', 'bg-theme bg-theme10');
    }

    function theme11() {
      $('#sidebar-wrapper').attr('class', 'bg-theme bg-theme11');
    }

    function theme12() {
      $('#sidebar-wrapper').attr('class', 'bg-theme bg-theme12');
    }

 $('.icon-menu.menu-icon').click();

    /**
     * This funcions is a capabillity of action request in API only GET.
     * @param String Endpoint, endpoint of API
     * @param String Method, method of API
     * @return Object Data 
     */
    function get_api_get_user( Endpoint, Id ){
		let settings = {

            "url": "http://192.168.252.59:5000/clients/" + Id,
            "method": "GET",
            "processData": false,
            "contentType": false,
        }
		$.ajax(settings)
		.done( (response) => {

			//Aplicando os dados da api
			$('.mt-2.user-title').text(response.name);
			$('.col-sm-6.col-md-8 h4').text(response.name);
			$('.cpf').html('<strong> CPF: </strong> ' + response.cpf);
			$('.email-e-nasc').html( response.email );
			$('.dt_nasc').html( response.registroDeNascimento );
			$('.celular').html('<strong> Celular: </strong> ' + response.celular[0].numero);

			$('.prob-geral-prog.mb-0.py-3.text-success').html( response.probabilidade.geral + '%' );
			$('.col-12.col-lg-3.text-center .prob-ind').html( response.probabilidade.individual + '%'  );
			const canvas_label_time = [];
			const canvas_renda_time = [];
			const canvas_desc_time = [];
			var renda_atual = 0;

			for (let index = 0; index < response.trilhagem[0].moment.length; index++) {

				canvas_label_time[index] = GetMouthByData(response.trilhagem[0].moment[index].data);
				canvas_renda_time[index] = response.trilhagem[0].moment[index].renda.split(',')[0];
				canvas_desc_time[index]  = response.trilhagem[0].moment[index].obs;
				renda_atual = response.trilhagem[0].moment[index].renda;

			}

			$('.renda-atual').html('R$ ' + renda_atual);

	
			$(function() {
				"use strict";
				  var ctx = document.getElementById('dash2-chart1').getContext('2d');
						var myChart = new Chart(ctx, {
							type: 'bar',
							data: {
								labels: canvas_label_time,
								datasets: [{
									label: '',
									type: 'line',
									data: canvas_renda_time,	
									backgroundColor: "rgba(3, 208, 234, 0.23)",
									borderColor: "#03d0ea",
									pointBackgroundColor:'transparent',
									pointHoverBackgroundColor:'#03d0ea',
									pointBorderWidth :2,
									pointRadius :3,
									pointHoverRadius :3,
									borderWidth: 3
									
								}],
							},
						options: {
							legend: {
							  display: false,
							  labels: {
								fontColor: '#585757',  
								boxWidth:1,
								boxHeight:1
							  }
							},
							tooltips: {
							  displayColors:true
							},	
						  scales: {
							  xAxes: [{
								barPercentage: .3,
								ticks: {
									beginAtZero:true,
									fontColor: '#585757'
								},
								gridLines: {
								  display: true ,
								  color: "rgba(0, 0, 0, 0.05)"
								},
							  }],
							   yAxes: [{
								ticks: {
									beginAtZero:true,
									fontColor: '#585757'
								},
								gridLines: {
								  display: true ,
								  color: "rgba(0, 0, 0, 0.05)"
								},
							  }]
							 }
			
						 }
						}); 
				  });


		})
		.error( (response) => {
			Snackbar.show({
				text: 'Error na solicitação',
				pos: 'bottom-center',
				showAction: false,
				actionTextColor: '#4CAF50',
				backgroundColor: '#FF5A50',
			});
		});
    }

	/**
	 * This funcions is a capabillity of action request in API only POST.
	 * @param String Endpoint, endpoint of API
	 * @param String Method, method of API
	 * @return Object Data 
	 */
	function get_api_post( Endpoint ){
			var settings = {
			"async": true,
			"crossDomain": true,
			"url": Endpoint,
			"method": "POST",
			"headers": {
			"Content-Type": "application/json",
			"cache-control": "no-cache",
			},
			"processData": false,
			"data": ""
			}
	
			$.ajax(settings)
			.done( (response) => {
				//Error
				Snackbar.show({
					text: response,
					pos: 'bottom-center',
					showAction: false,
					actionTextColor: '#4CAF50',
					backgroundColor: '#14abef',
				});
			})
			.error( (response) => {
				//Error
				Snackbar.show({
					text: response,
					pos: 'bottom-center',
					showAction: false,
					actionTextColor: '#4CAF50',
					backgroundColor: '#FF5A50',
				});
			});
	}

	// ex: 10/10/2019
	function GetMouthByData( Data ){
		let dataMouth = Data.split('/')[1];
		switch (dataMouth) {
			case '01':
				return 'Jan';
			case '02':
				return 'Fev';
			case '03':
				return 'Mar';
			case '04':
				return 'Abr';
			case '05':
				return 'Mai';
			case '06':
				return 'Jun';
			case '07':
				return 'Jul';
			case '08':
				return 'Ago';
			case '09':
				return 'Set';
			case '10':
				return 'Out';
			case '11':
				return 'Nov';
			case '12':
				return 'Dez';
		
			default:
				return '';
				break;
		}
	}
	get_api_get_user( '192.168.252.59:5000/clients/', '5dac40372366d4189d0d0cc0' );
});